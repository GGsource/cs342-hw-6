
public interface Coffee {
	public double makeCoffee();
}
